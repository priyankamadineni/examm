# Tic Tac Toe Online Multiplayer

Simple Tic Tac Toe Online Multiplayer made with Flutter for mobile application and NodeJS to create the Server.

## What's Special:

Whole system depend on UDP Socket Programming. Though it's common in NodeJS and I previously worked on it but for Flutter,it being new, I did not have any exposure to RawDatagramSocket class or it's working procedures. I enjoyed creating this project.Hope you will like it too.

### Note:

Please change the IP addresses whereever it's mentioned to make it work for you.I tested it on localhost. So all the IP addresses are my local IPs only.

## YouTube Video Demo:

<a href="http://www.youtube.com/watch?feature=player_embedded&v=fxMR8VEAb1s
" target="_blank"><img src="http://img.youtube.com/vi/fxMR8VEAb1s/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="480" height="320" border="10" /></a>
